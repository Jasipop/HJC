此为4.7组会ddl的第二阶段前端任务，即完成各部分分块儿的页面，未设置跳转。下一阶段完成跳转
包含：
报销列表 Reimbursement List
新建报销 Add New Reimbursement
信箱 Mailbox
设置 Settings

运行配置在.idea文件里（其实就是javafx的sdk库）
